import os
import binascii
f = open("PNet.cfg", 'r', True)
while True:
  ch = f.read(1)
     
  if not ch: break
  if (ch == "\n") :
  	#hex=(binascii.hexlify('\n')
    print("0x0D,",end="")
  else:
  	#hex=(binascii.hexlify(ch)
    print("'%c',"%ch,end=" ")