/*
 ============================================================================
 Name        : exa1.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include "mtcnn.h"

int main( ) {
#if 0
	    int i;
   	    char ch[100];
   	    FILE* fp = fopen("e:/study/Xilinx_ZC706/act.dat","r+");
   		fread(ch, sizeof(char), 100, fp);
   		for(i=0; i<100; i++)
   		  printf("%c", ch[i]);
	    puts("!!!Hello World!!!"); /* prints !!!Hello World!!! */
#endif
	    int argc;
	    char* argv[20];
	    puts("!!!Hello World!!!"); /* prints !!!Hello World!!! */
	    puts("!!!Hello World!!!"); /* prints !!!Hello World!!! */
	    // load image
	    network *pnet = load_mtcnn_net("PNet");
	    network *rnet = load_mtcnn_net("RNet");
	    network *onet = load_mtcnn_net("ONet");
#if 1
	    argc = 14;
	    argv[0] = "-v";
	    argv[1]	= "0";
	    argv[2]	="-p";
	    argv[3]	="0.6";
	    argv[4]	="-r";
	    argv[5]	="0.7";
	    argv[6]	="-o";
	    argv[7]	="0.7";
	    argv[8]	="--scale";
	    argv[9]	="0.709";
	    argv[10] ="--minface";
	    argv[11] ="12";
	    argv[12] = "--path";
	    argv[13] ="e:/study/ARM/images/test.jpg";
#endif
	    printf("\n\n");

	    printf("Loading image...");
	    char* filepath = find_char_arg(argc, argv, "--path", "e:/study/ARM/images/test.jpg");
	    if(0==strcmp(filepath, "e:/study/ARM/images/test.jpg")){
	        fprintf(stderr, "Using default: %s\n", filepath);
	    }
	    image im = load_image_color(filepath, 0, 0);    // RGB, 0.~1.
	    show_image(im, "image", 0);
	    printf("OK!\n");

	    printf("Initializing detection...");
	    params p = initParams(argc, argv);
	    detect* dets = calloc(0, sizeof(detect)); int n = 0;
	    printf("OK!\n");

	    double start = 0;
	    double endure = 0;

	    start = what_time_is_it_now();
	    detect_image(pnet, rnet, onet, im, &n, &dets, p);
	    endure = what_time_is_it_now() - start;
	    printf("Predicted in %.2f seconds. FPS: %.2f\n", endure, 1 / endure);
	    printf("Objects:%d\n", n);
	    show_detect(im, dets, n, "mtcnn", 0, 1, 1, 1);

	    free_image(im);
	    free(dets);

	    free_network(pnet);
	    free_network(rnet);
	    free_network(onet);

	return EXIT_SUCCESS;
}
